function todo(){
    let text=document.getElementById('in1').value;
    let li=document.createElement('li');
    li.innerHTML=text;
    document.getElementById('out1').appendChild(li);
    
}